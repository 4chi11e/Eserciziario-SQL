<!-- pagina per l'inserimento dei clienti nei voli, compresi gli accompagnatori -->

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>clienti in voli</title>
</head>

<body>
    <h1>Inserimento dei clienti nei voli</h1>
    <?php
    function myrand($min, $max)
    {
        $rand01 = mt_rand(0, mt_getrandmax() - 1) / mt_getrandmax();
        return ($rand01 * ($max - $min)) + $min;
    }

    $conn = new mysqli("localhost", "root", "", "aeroporti");
    if ($conn->error) {
        echo "<p>Errore nella connessione al db: " . $conn->error . "</p>";
    }

    // query per caricarmi la tabella dei clienti
    $query = "SELECT * FROM cliente";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare i clienti: " . $conn->error . "</p>");
    $clienti = array();
    foreach ($ris as $riga) {
        // array_push($clienti, array($riga["codcliente"], $riga["data_nascita"]));
        array_push($clienti, $riga);
    }

    // // stampa dei dati raccolti come vettore (debug)
    // echo "<ol>";
    // foreach($durate_vettore as $riga){
    //     echo "<li>".$riga[0]." - ".$riga[1]." - ".$riga[2]."</li>";
    // }

    // query per caricarmi le info sui voli
    $query = "  SELECT codvolo, datapartenza, nposti
                FROM volo JOIN aereo ON volo.aereo = aereo.codaereo
                    JOIN modello ON aereo.codmodello = modello.codmodello";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare i voli: " . $conn->error . "</p>");
    $voli = array();
    foreach ($ris as $riga) {
        // array_push($voli, array($riga["codvolo"], $riga["datapartenza"], $riga["nposti"]));
        array_push($voli, $riga);
    }

    // ora voglio inserire clienti casuali nel volo

    // azzero l'auto increment
    $query = "ALTER TABLE volo AUTO_INCREMENT = 0;";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di azzerare l'auto increment di voli: " . $conn->error . "</p>");

    // ciclo su tutti i voli
    foreach ($voli as $volo) {
        $codvolo = $volo["codvolo"];
        $data_partenza = $volo["datapartenza"];
        $tempo_partenza = strtotime($data_partenza);
        $nposti = $volo["nposti"];
        $aggiungo = true;
        $liberi = $nposti;
        $pos_clienti_aggiunti = array();

        //echo "<p>";
        while ($aggiungo) {
            do {
                $pos = rand(0, sizeof($clienti) - 1);
            } while (in_array($pos, $pos_clienti_aggiunti));
            array_push($pos_clienti_aggiunti, $pos);
            $liberi = $liberi - 1;

            // decido se aggiungere un nuovo passeggero
            $prob = 0.98 + ($liberi / $nposti * 0.03);
            //printf("%.2f  ",$prob);
            if (myrand(0.0, 1.0) > $prob || $liberi <= 0) {
                $aggiungo = false;
            }
        }
        //echo "</p>";
        //echo "<p>Rimasti liberi $liberi posti su $nposti</p>";

        // scelgo gli accompagnatori
        $pos_accompagnatori = array();
        foreach ($pos_clienti_aggiunti as $pos_cliente_aggiunto) {
            $data_nascita = $clienti[$pos_cliente_aggiunto]["data_nascita"];
            $tempo_nascita = strtotime($data_nascita);
            if ($tempo_partenza < strtotime('+18 years', $tempo_nascita)) {
                do {
                    $pos_accompagnatore = $pos_clienti_aggiunti[rand(0, sizeof($pos_clienti_aggiunti) - 1)];
                    $data_nascita_accompagnatore = $clienti[$pos_accompagnatore]["data_nascita"];
                    $tempo_nascita_accompagnatore = strtotime($data_nascita_accompagnatore);
                } while ($pos_accompagnatore == $pos_cliente_aggiunto or $tempo_partenza < strtotime('+18 years', $tempo_nascita_accompagnatore));
                // echo "<p>$data_nascita - $data_nascita_accompagnatore</p>";
            } else {
                $pos_accompagnatore = -1;
                // echo "<p>$data_nascita - OK!</p>";
            }
            array_push($pos_accompagnatori, $pos_accompagnatore);
        }

        // adesso devo inserire tutte le cose scelte: clienti e rispettivi accompagnatori
        // prendo clienti da $pos_clienti_aggiunti che fa riferimento a $clienti
        // uso anche $pos_accompagnatore che fa riferimento ad un altro cliente aggiunto (-1 se il cliente non ha accompagnatore)

        for ($i = 0; $i < sizeof($pos_clienti_aggiunti); $i++) {
            $codcliente = $clienti[$pos_clienti_aggiunti[$i]]["codcliente"];
            $query = "INSERT INTO vola (codcliente, codvolo)
                      VALUES ($codcliente, $codvolo)";
            $conn->query($query) or die("<p>Errore quando cerco di inserire una relazione volo cliente: " . $conn->error . "</p>");

            if ($pos_accompagnatori[$i] != -1) {
                $codaccompagnatore = $clienti[$pos_accompagnatori[$i]]["codcliente"];
                $query = "INSERT INTO accompagna (accompagnato, accompagnatore, volo)
                      VALUES ($codcliente, $codaccompagnatore, $codvolo)";
                $conn->query($query) or die("<p>Errore quando cerco di inserire una relazione accompagnatore: " . $conn->error . "</p>");
                // echo "<p>Accompangatore inserito: $codcliente, $codaccompagnatore, $codvolo</p>";
            }
        }
    }
    // for ($i = 1; $i <= 100; $i++) {


    // }

    ?>
</body>

</html>