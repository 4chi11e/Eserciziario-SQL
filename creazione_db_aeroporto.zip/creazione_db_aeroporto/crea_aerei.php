<!-- pagina per la creazione degli aerei a partire da modelli e compagnie che devono già essere stati inseriti -->

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riempi "durate voli"</title>
</head>

<body>
    <h1>Riempimento Aerei</h1>
    <?php
    $conn = new mysqli("localhost", "root", "", "aeroporti");
    if ($conn->error) {
        echo "<p>Errore nella connessione al db: " . $conn->error . "</p>";
    }

    // Creo gli aerei a partire da compagnie e modelli
    $query = "SELECT * FROM modello";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare i modelli: " . $conn->error . "</p>");
    $modelli_vettore = array();
    foreach ($ris as $riga) {
        array_push($modelli_vettore, $riga["codmodello"]);
    }
    $num_modelli = sizeof($modelli_vettore);

    $query = "SELECT * FROM compagnia";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare le compagnie: " . $conn->error . "</p>");
    $compagnie_vettore = array();
    foreach ($ris as $riga) {
        array_push($compagnie_vettore, $riga["codcompagnia"]);
    }
    $num_compagnie = sizeof($compagnie_vettore);

    for ($i = 1; $i <= 50; $i++) {
        $cod_compagnia = $compagnie_vettore[rand(0, $num_compagnie - 1)];
        $cod_modello = $modelli_vettore[rand(0, $num_modelli - 1)];
        $anno_costruzione = rand(2000, 2021);
        // in questo modo la maggior parte sono comprati nuovi
        $anno_acquisto = rand(1985, 2021);
        if($anno_acquisto < $anno_costruzione){
            $anno_acquisto = $anno_costruzione;
        }

        // stampo i dati dell'aereo costruito e che andrò a mettere nel db
        echo "<p>Compagnia: " . $cod_compagnia . ", Modello: " . $cod_modello . ", Anno costruzione: " . $anno_costruzione . ", Anno acquisto: " . $anno_acquisto . "</p>";

        // costruisco la query
        $query = "INSERT INTO aereo (codmodello, codcompagnia, anno_costruzione, anno_acquisto)
                  VALUES ($cod_modello, $cod_compagnia, $anno_costruzione, $anno_acquisto)";
        $conn->query($query) or die("<p>Errore quando cerco di inserire un aereo: " . $conn->error . "</p>");
        // $cod_aereo = $conn->insert_id;
    }



    ?>
</body>

</html>