<!-- pagina per la creazione dei clienti pescando dal database dei nomi e dei cognomi -->

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riempi "durate voli"</title>
</head>

<body>
    <h1>Riempimento Aerei</h1>
    <?php
    $db_nomi_cognomi = new mysqli("localhost", "root", "", "nomi_e_cognomi");
    if ($db_nomi_cognomi->error) {
        echo "<p>Errore nella connessione al db nomi e cognomi: " . $conn->error . "</p>";
    }
    $db_aeroporti = new mysqli("localhost", "root", "", "aeroporti");
    if ($db_aeroporti->error) {
        echo "<p>Errore nella connessione al db aeroporti: " . $conn->error . "</p>";
    }

    // carico i nomi
    $query = "SELECT * FROM nome";
    $ris = $db_nomi_cognomi->query($query) or die("<p>Errore quando cerco di caricare i nomi: " . $db_nomi_cognomi->error . "</p>");
    $nomi_vettore = array();
    foreach ($ris as $riga) {
        array_push($nomi_vettore, $riga["nome"]);
    }
    $num_nomi = sizeof($nomi_vettore);

    $query = "SELECT * FROM cognome";
    $ris = $db_nomi_cognomi->query($query) or die("<p>Errore quando cerco di caricare i cognomi: " . $db_aeroporti->error . "</p>");
    $cognomi_vettore = array();
    foreach ($ris as $riga) {
        array_push($cognomi_vettore, $riga["cognome"]);
    }
    $num_cognomi = sizeof($cognomi_vettore);

    // azzero l'autoincrement di cliente
    $query = "ALTER TABLE cliente AUTO_INCREMENT = 0;";
    $ris = $db_aeroporti->query($query) or die("<p>Errore quando cerco di azzerare l'auto increment di cliente: " . $db_aeroporti->error . "</p>");

    // ora creo n clienti
    $n = 3000;
    for ($i = 1; $i <= $n; $i++) {
        $cognome = $cognomi_vettore[rand(0, $num_cognomi - 1)];
        $nome = $nomi_vettore[rand(0, $num_nomi - 1)];

        // costruisco la data di nascita
        // Convert to timetamps
        $min = strtotime("1940-01-01");
        $max = strtotime("2020-12-31");
        // Generate random number using above bounds
        $val = rand($min, $max);
        // Convert back to desired date format
        $data_nascita = date('Y-m-d', $val);

        // stampo i dati del cliente che andrò a mettere nel db
        echo "<p>Cognome: " . $cognome . ", Nome: " . $nome . ", Data di nascita: " . $data_nascita . " ". gettype($data_nascita). "</p>";

        // costruisco la query
        $query = "INSERT INTO cliente (cognome, nome, data_nascita)
                  VALUES ('$cognome', '$nome', '$data_nascita')";
        $db_aeroporti->query($query) or die("<p>Errore quando cerco di inserire un cliente: " . $db_aeroporti->error . "</p>");
        // $cod_aereo = $conn->insert_id;
    }



    ?>
</body>

</html>