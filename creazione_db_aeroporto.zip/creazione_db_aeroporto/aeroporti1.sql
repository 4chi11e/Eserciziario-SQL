-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versione server:              10.4.21-MariaDB - mariadb.org binary distribution
-- S.O. server:                  Win64
-- HeidiSQL Versione:            11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dump della struttura del database aeroporti
CREATE DATABASE IF NOT EXISTS `aeroporti` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `aeroporti`;

-- Dump della struttura di tabella aeroporti.accompagna
CREATE TABLE IF NOT EXISTS `accompagna` (
  `accompagnato` int(10) unsigned NOT NULL,
  `accompagnatore` int(10) unsigned NOT NULL,
  `volo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`accompagnato`,`accompagnatore`,`volo`),
  KEY `FK_accompagna_cliente_2` (`accompagnatore`),
  KEY `FK_accompagna_volo` (`volo`),
  CONSTRAINT `FK_accompagna_cliente` FOREIGN KEY (`accompagnato`) REFERENCES `cliente` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_accompagna_cliente_2` FOREIGN KEY (`accompagnatore`) REFERENCES `cliente` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_accompagna_volo` FOREIGN KEY (`volo`) REFERENCES `volo` (`codvolo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.accompagna: ~0 rows (circa)
/*!40000 ALTER TABLE `accompagna` DISABLE KEYS */;
/*!40000 ALTER TABLE `accompagna` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.aereo
CREATE TABLE IF NOT EXISTS `aereo` (
  `codaereo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codmodello` int(10) unsigned DEFAULT NULL,
  `nposti` int(10) unsigned DEFAULT NULL,
  `codcompagnia` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codaereo`),
  KEY `FK_aereo_compagnia` (`codcompagnia`),
  KEY `FK_aereo_modello` (`codmodello`),
  CONSTRAINT `FK_aereo_compagnia` FOREIGN KEY (`codcompagnia`) REFERENCES `compagnia` (`codcompagnia`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_aereo_modello` FOREIGN KEY (`codmodello`) REFERENCES `modello` (`codmodello`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.aereo: ~0 rows (circa)
/*!40000 ALTER TABLE `aereo` DISABLE KEYS */;
/*!40000 ALTER TABLE `aereo` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.aeroporto
CREATE TABLE IF NOT EXISTS `aeroporto` (
  `codaeroporto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `localita` char(50) DEFAULT NULL,
  `nome_commerciale` char(100) DEFAULT NULL,
  `codcitta` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codaeroporto`),
  KEY `FK_aeroporto_citta` (`codcitta`),
  CONSTRAINT `FK_aeroporto_citta` FOREIGN KEY (`codcitta`) REFERENCES `citta` (`codcitta`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.aeroporto: ~13 rows (circa)
/*!40000 ALTER TABLE `aeroporto` DISABLE KEYS */;
INSERT INTO `aeroporto` (`codaeroporto`, `localita`, `nome_commerciale`, `codcitta`) VALUES
	(1, 'Roma-Fiumicino', 'Aeroporto intercontinentale Leonardo da Vinci', 10),
	(2, 'Milano-Malpensa', 'Milano Malpensa Airport', 1),
	(3, 'Catania', 'Aeroporto Internazionale Vincenzo Bellini', 7),
	(4, 'Bergamo-Orio al Serio', 'Aeroporto Internazionale Il Caravaggio', 2),
	(5, 'Palermo', 'Aeroporto Internazionale Falcone e Borsellino', 6),
	(6, 'Milano-Linate', 'Aeroporto Enrico Forlanini', 1),
	(7, 'Londra-Heathrow', 'Aeroporto Intercontinentale di Londra-Heathrow', 4),
	(8, 'Parigi-Charles de Gaulle', 'Aeroporto di Parigi Charles de Gaulle', 3),
	(9, 'Londra-Stansted', 'Aeroporto di Londra Stansted', 4),
	(10, 'Londra-Gatwick', 'Aeroporto di Londra-Gatwick', 4),
	(11, 'Francoforte', 'Aeroporto di Francoforte sul Meno', 8),
	(12, 'Parigi-Orly', 'Aeroporto di Parigi-Orly', 3),
	(13, 'Madrid-Barajas', 'Aeroporto Adolfo Suárez Madrid-Barajas', 5);
/*!40000 ALTER TABLE `aeroporto` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.citta
CREATE TABLE IF NOT EXISTS `citta` (
  `codcitta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` char(50) DEFAULT NULL,
  `nazione` char(50) DEFAULT NULL,
  `abitanti` int(10) unsigned DEFAULT NULL,
  `abitanti_agglomerato` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codcitta`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.citta: ~8 rows (circa)
/*!40000 ALTER TABLE `citta` DISABLE KEYS */;
INSERT INTO `citta` (`codcitta`, `nome`, `nazione`, `abitanti`, `abitanti_agglomerato`) VALUES
	(1, 'Milano', 'Italia', 1398000, 4994000),
	(2, 'Bergamo', 'Italia', 120287, NULL),
	(3, 'Parigi', 'Francia', 2176000, 11027000),
	(4, 'Londra', 'Regno Unito', 9048000, 11120000),
	(5, 'Madrid', 'Spagna', 3335000, 6006000),
	(6, 'Palermo', 'Italia', 673735, NULL),
	(7, 'Catania', 'Italia', 313396, NULL),
	(8, 'Francoforte', 'Germania', 763000, 1941000),
	(10, 'Roma', 'Italia', 2784000, 3207000);
/*!40000 ALTER TABLE `citta` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `codcliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` char(50) DEFAULT NULL,
  `cognome` char(50) DEFAULT NULL,
  `eta` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codcliente`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.cliente: ~19 rows (circa)
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`codcliente`, `nome`, `cognome`, `eta`) VALUES
	(2, '﻿Amici', 'Ester', NULL),
	(3, 'Biella', 'Marta', NULL),
	(4, 'Brescia', 'Valentina', NULL),
	(5, 'Carolla', 'Matteo', NULL),
	(6, 'Cereda', 'Luca', NULL),
	(7, 'Cunegatti', 'Gabriele', NULL),
	(8, 'De Bella', 'Ilaria', NULL),
	(9, 'De Vecchi', 'Filippo', NULL),
	(10, 'Galimberti', 'Andrea', NULL),
	(11, 'Germanò', 'Matteo', NULL),
	(12, 'Gubellini', 'Giulia', NULL),
	(13, 'Maconi', 'Filippo', NULL),
	(14, 'Mariani', 'Matteo', NULL),
	(15, 'Mattavelli', 'Andrea', NULL),
	(16, 'Passoni', 'Giorgia', NULL),
	(17, 'Pirovano', 'Bianca', NULL),
	(18, 'Rudi', 'Roberto', NULL),
	(19, 'Tezza', 'Matteo', NULL),
	(20, 'Varisco', 'Marco', NULL);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.compagnia
CREATE TABLE IF NOT EXISTS `compagnia` (
  `codcompagnia` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` char(50) DEFAULT NULL,
  `nazione` char(50) DEFAULT NULL,
  PRIMARY KEY (`codcompagnia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.compagnia: ~0 rows (circa)
/*!40000 ALTER TABLE `compagnia` DISABLE KEYS */;
/*!40000 ALTER TABLE `compagnia` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.copiloti
CREATE TABLE IF NOT EXISTS `copiloti` (
  `codvolo` int(10) unsigned NOT NULL,
  `codpilota` int(10) unsigned NOT NULL,
  PRIMARY KEY (`codvolo`,`codpilota`),
  KEY `FK_copiloti_pilota` (`codpilota`),
  CONSTRAINT `FK_copiloti_pilota` FOREIGN KEY (`codpilota`) REFERENCES `pilota` (`codpilota`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_copiloti_volo` FOREIGN KEY (`codvolo`) REFERENCES `volo` (`codvolo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.copiloti: ~0 rows (circa)
/*!40000 ALTER TABLE `copiloti` DISABLE KEYS */;
/*!40000 ALTER TABLE `copiloti` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.durate_voli
CREATE TABLE IF NOT EXISTS `durate_voli` (
  `partenza` int(10) unsigned NOT NULL,
  `arrivo` int(10) unsigned NOT NULL,
  `durata` time DEFAULT NULL,
  KEY `FK_durate_voli_aeroporto` (`partenza`),
  KEY `FK_durate_voli_aeroporto_2` (`arrivo`),
  CONSTRAINT `FK_durate_voli_aeroporto` FOREIGN KEY (`partenza`) REFERENCES `aeroporto` (`codaeroporto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_durate_voli_aeroporto_2` FOREIGN KEY (`arrivo`) REFERENCES `aeroporto` (`codaeroporto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.durate_voli: ~78 rows (circa)
/*!40000 ALTER TABLE `durate_voli` DISABLE KEYS */;
INSERT INTO `durate_voli` (`partenza`, `arrivo`, `durata`) VALUES
	(2, 3, '02:00:00'),
	(2, 4, '00:11:00'),
	(2, 5, '01:43:00'),
	(2, 6, '00:07:00'),
	(2, 7, '01:47:00'),
	(2, 8, '01:32:00'),
	(2, 9, '01:46:00'),
	(2, 10, '01:43:00'),
	(2, 11, '01:15:00'),
	(2, 12, '01:31:00'),
	(2, 13, '02:11:00'),
	(6, 7, '01:52:00'),
	(6, 8, '01:40:00'),
	(6, 9, '01:51:00'),
	(6, 10, '01:48:00'),
	(6, 11, '01:19:00'),
	(6, 12, '01:38:00'),
	(6, 13, '02:15:00'),
	(4, 5, '01:40:00'),
	(4, 6, '00:06:00'),
	(4, 7, '01:53:00'),
	(4, 8, '01:41:00'),
	(4, 9, '01:52:00'),
	(4, 10, '01:48:00'),
	(4, 11, '01:16:00'),
	(4, 12, '01:40:00'),
	(4, 13, '02:15:00'),
	(8, 9, '00:55:00'),
	(8, 10, '00:47:00'),
	(8, 11, '01:09:00'),
	(8, 12, '00:04:00'),
	(8, 13, '02:01:00'),
	(12, 13, '01:58:00'),
	(7, 8, '00:54:00'),
	(7, 9, '00:10:00'),
	(7, 10, '00:06:00'),
	(7, 11, '01:41:00'),
	(7, 12, '00:56:00'),
	(7, 13, '02:18:00'),
	(9, 10, '00:13:00'),
	(9, 11, '01:35:00'),
	(9, 12, '00:59:00'),
	(9, 13, '02:04:00'),
	(10, 11, '01:37:00'),
	(10, 12, '00:50:00'),
	(10, 13, '02:15:00'),
	(5, 6, '01:39:00'),
	(5, 7, '02:49:00'),
	(5, 8, '02:20:00'),
	(5, 9, '02:49:00'),
	(5, 10, '02:45:00'),
	(5, 11, '02:10:00'),
	(5, 12, '02:19:00'),
	(5, 13, '02:19:00'),
	(3, 4, '01:56:00'),
	(3, 5, '00:29:00'),
	(3, 6, '01:55:00'),
	(3, 7, '03:04:00'),
	(3, 8, '02:32:00'),
	(3, 9, '03:04:00'),
	(3, 10, '03:00:00'),
	(3, 11, '02:22:00'),
	(3, 12, '02:30:00'),
	(3, 13, '02:33:00'),
	(11, 12, '01:12:00'),
	(11, 13, '02:15:00'),
	(1, 2, '01:18:00'),
	(1, 3, '01:22:00'),
	(1, 4, '01:14:00'),
	(1, 5, '01:04:00'),
	(1, 6, '01:13:00'),
	(1, 7, '02:18:00'),
	(1, 8, '02:06:00'),
	(1, 9, '02:18:00'),
	(1, 10, '02:14:00'),
	(1, 11, '01:50:00'),
	(1, 12, '02:05:00'),
	(1, 13, '02:07:00');
/*!40000 ALTER TABLE `durate_voli` ENABLE KEYS */;

-- Dump della struttura di vista aeroporti.durate_voli_con_nomi
-- Creazione di una tabella temporanea per risolvere gli errori di dipendenza della vista
CREATE TABLE `durate_voli_con_nomi` (
	`partenza` CHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`arrivo` CHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`durata` TIME NULL
) ENGINE=MyISAM;

-- Dump della struttura di tabella aeroporti.modello
CREATE TABLE IF NOT EXISTS `modello` (
  `codmodello` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `marca` char(50) DEFAULT NULL,
  `nome` char(50) DEFAULT NULL,
  `nposti` int(10) unsigned DEFAULT NULL,
  `lunghezza` float unsigned DEFAULT NULL,
  `apertura_alare` float unsigned DEFAULT NULL,
  `peso_vuoto` float unsigned DEFAULT NULL,
  `peso_massimo` float unsigned DEFAULT NULL,
  PRIMARY KEY (`codmodello`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.modello: ~7 rows (circa)
/*!40000 ALTER TABLE `modello` DISABLE KEYS */;
INSERT INTO `modello` (`codmodello`, `marca`, `nome`, `nposti`, `lunghezza`, `apertura_alare`, `peso_vuoto`, `peso_massimo`) VALUES
	(1, 'Airbus', 'A320', 195, 37.57, 34.1, 42600, 73000),
	(2, 'Boeing', '737', 136, 30.53, 28.35, 29620, 58105),
	(3, 'Boeing', '777', 550, 73.86, 64.8, 167829, 252000),
	(4, 'Airbus', 'A330', NULL, NULL, NULL, NULL, NULL),
	(5, 'Boeing', '767', NULL, NULL, NULL, NULL, NULL),
	(6, 'Airbus', 'A300', 361, 53.85, 44.84, 87500, 165000),
	(7, 'Airbus', 'A340', NULL, NULL, NULL, NULL, NULL),
	(8, 'Boeing', '757', NULL, NULL, NULL, NULL, NULL),
	(9, 'McDonnell Douglas', 'DC-9', NULL, NULL, NULL, NULL, NULL),
	(10, 'Boeing', '747', NULL, NULL, NULL, NULL, NULL),
	(11, 'Embraer', '190', NULL, NULL, NULL, NULL, NULL),
	(12, 'ATR', '42', NULL, NULL, NULL, NULL, NULL),
	(13, 'ATR', '72', NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `modello` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.pilota
CREATE TABLE IF NOT EXISTS `pilota` (
  `codpilota` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nome` char(50) DEFAULT NULL,
  `cognome` char(50) DEFAULT NULL,
  `nazionalita` char(50) DEFAULT NULL,
  `stipendio` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codpilota`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.pilota: ~9 rows (circa)
/*!40000 ALTER TABLE `pilota` DISABLE KEYS */;
INSERT INTO `pilota` (`codpilota`, `nome`, `cognome`, `nazionalita`, `stipendio`) VALUES
	(1, '﻿Bergonzi', 'Martina', NULL, NULL),
	(2, 'Borghesan', 'Giorgia', NULL, NULL),
	(3, 'Carrettiero', 'Filippo', NULL, NULL),
	(4, 'Casanova', 'Patrick', NULL, NULL),
	(5, 'Compagnoni', 'Andrea', NULL, NULL),
	(6, 'Di Valentin', 'Simone', NULL, NULL),
	(7, 'Faustini', 'Mattia', NULL, NULL),
	(8, 'Grigoli', 'Edoardo', NULL, NULL),
	(9, 'Lintas', 'Sara', NULL, NULL);
/*!40000 ALTER TABLE `pilota` ENABLE KEYS */;

-- Dump della struttura di tabella aeroporti.vola
CREATE TABLE IF NOT EXISTS `vola` (
  `codcliente` int(10) unsigned NOT NULL,
  `codvolo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`codcliente`,`codvolo`),
  KEY `FK_vola_volo` (`codvolo`),
  CONSTRAINT `FK_vola_cliente` FOREIGN KEY (`codcliente`) REFERENCES `cliente` (`codcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_vola_volo` FOREIGN KEY (`codvolo`) REFERENCES `volo` (`codvolo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.vola: ~0 rows (circa)
/*!40000 ALTER TABLE `vola` DISABLE KEYS */;
/*!40000 ALTER TABLE `vola` ENABLE KEYS */;

-- Dump della struttura di vista aeroporti.voli_amichevole
-- Creazione di una tabella temporanea per risolvere gli errori di dipendenza della vista
CREATE TABLE `voli_amichevole` (
	`partenza` CHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`datapartenza` DATE NULL,
	`orapartenza` TIME NULL,
	`arrivo` CHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`dataarrivo` DATE NULL,
	`oraarrivo` TIME NULL
) ENGINE=MyISAM;

-- Dump della struttura di tabella aeroporti.volo
CREATE TABLE IF NOT EXISTS `volo` (
  `codvolo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aeroportopartenza` int(10) unsigned DEFAULT NULL,
  `datapartenza` date DEFAULT NULL,
  `orapartenza` time DEFAULT NULL,
  `aeroportoarrivo` int(10) unsigned DEFAULT NULL,
  `dataarrivo` date DEFAULT NULL,
  `oraarrivo` time DEFAULT NULL,
  `aereo` int(10) unsigned DEFAULT NULL,
  `comandante` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codvolo`),
  KEY `FK_volo_aeroporto` (`aeroportopartenza`),
  KEY `FK_volo_aeroporto_2` (`aeroportoarrivo`),
  KEY `FK_volo_aereo` (`aereo`),
  KEY `FK_volo_pilota` (`comandante`),
  CONSTRAINT `FK_volo_aereo` FOREIGN KEY (`aereo`) REFERENCES `aereo` (`codaereo`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_volo_aeroporto` FOREIGN KEY (`aeroportopartenza`) REFERENCES `aeroporto` (`codaeroporto`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_volo_aeroporto_2` FOREIGN KEY (`aeroportoarrivo`) REFERENCES `aeroporto` (`codaeroporto`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_volo_pilota` FOREIGN KEY (`comandante`) REFERENCES `pilota` (`codpilota`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dump dei dati della tabella aeroporti.volo: ~0 rows (circa)
/*!40000 ALTER TABLE `volo` DISABLE KEYS */;
/*!40000 ALTER TABLE `volo` ENABLE KEYS */;

-- Dump della struttura di vista aeroporti.durate_voli_con_nomi
-- Rimozione temporanea di tabella e creazione della struttura finale della vista
DROP TABLE IF EXISTS `durate_voli_con_nomi`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `durate_voli_con_nomi` AS SELECT AP.localita AS partenza, AA.localita AS arrivo, durata
FROM durate_voli JOIN aeroporto AS AP ON durate_voli.partenza = AP.codaeroporto
	JOIN aeroporto AS AA ON durate_voli.arrivo = AA.codaeroporto WITH CASCADED CHECK OPTION ;

-- Dump della struttura di vista aeroporti.voli_amichevole
-- Rimozione temporanea di tabella e creazione della struttura finale della vista
DROP TABLE IF EXISTS `voli_amichevole`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `voli_amichevole` AS SELECT AP.localita AS partenza, datapartenza, orapartenza, AA.localita AS arrivo,dataarrivo, oraarrivo 
FROM volo JOIN aeroporto AS AP ON volo.aeroportopartenza = AP.codaeroporto
	JOIN aeroporto AS AA ON volo.aeroportoarrivo = AA.codaeroporto ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
