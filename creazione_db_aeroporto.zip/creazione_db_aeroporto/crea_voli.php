<!-- pagina per la creazione dei voli a partire da tutto il resto del database che deve già essere completo -->

<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riempi "durate voli"</title>
</head>

<body>
    <h1>Riempimento Voli</h1>
    <?php
    $conn = new mysqli("localhost", "root", "", "aeroporti");
    if ($conn->error) {
        echo "<p>Errore nella connessione al db: " . $conn->error . "</p>";
    }

    // query per caricarmi la tabella delle durate dei voli
    $query = "SELECT * FROM durata_volo";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare le durate dei voli: " . $conn->error . "</p>");

    // durate come vettore
    $durate_vettore = array();
    foreach ($ris as $riga) {
        array_push($durate_vettore, array($riga["partenza"], $riga["arrivo"], $riga["durata"]));
    }
    // // stampa dei dati raccolti come vettore (debug)
    // echo "<ol>";
    // foreach($durate_vettore as $riga){
    //     echo "<li>".$riga[0]." - ".$riga[1]." - ".$riga[2]."</li>";
    // }

    // durate come mappa
    $durate_mappa = array();
    foreach ($ris as $riga) {
        $key = $riga["partenza"] . "-" . $riga["arrivo"];
        $durate_mappa[$key] = $riga["durata"];
    }
    // stampa dei dati raccolti come mappa (debug)
    // echo "<ol>";
    // foreach($durate_mappa as $key => $value){
    //     echo "<li>".$key.": ".$value."</li>";
    // }


    // ora voglio generare dei voli casuali

    // azzero l'auto increment
    $query = "ALTER TABLE volo AUTO_INCREMENT = 0;";
    $ris = $conn->query($query) or die("<p>Errore quando cerco di azzerare l'auto increment di voli: " . $conn->error . "</p>");

    // genero i voli
    for ($i = 1; $i <= 100; $i++) {

        // pesco una tratta a caso con la sua durata pescando dalla tabella delle durate
        $indice = rand(0, sizeof($durate_vettore) - 1);
        $cod_partenza = $durate_vettore[$indice][0];
        $cod_arrivo = $durate_vettore[$indice][1];
        $durata = $durate_vettore[$indice][2];

        // genero data e ora di partenza
        $giorno_min = strtotime("2020-01-01");
        $giorno_max = strtotime("2021-12-31");
        $tempo_partenza = rand($giorno_min, $giorno_max);
        //$tempo_partenza = ceil($tempo_partenza/300)*300;    // trucco per approssimare ai 5 minuti successivi
        $durata_vettore = explode(":", $durata);
        $durata_ore = intval($durata_vettore[0]);
        $durata_minuti = intval($durata_vettore[1]);
        $durata_in_secondi = $durata_ore * 60 * 60 + $durata_minuti * 60;
        $tempo_durata = $durata_in_secondi;
        $tempo_arrivo = $tempo_partenza + $tempo_durata;
        $data_partenza = date('Y-m-d', $tempo_partenza);
        $ora_partenza = date('H:i', $tempo_partenza);
        $data_arrivo = date('Y-m-d', $tempo_arrivo);
        $ora_arrivo = date('H:i', $tempo_arrivo);

        // echo "<p>Tempo partenza: " . date('Y-m-d h:i', $tempo_partenza) . "<br>";
        // echo "Durata: " . $durata . "<br>";
        // echo "Tempo arrivo: " . date('Y-m-d h:i', $tempo_arrivo) . "</p>";


        // ora aggiungo i piloti
        $query = "SELECT * FROM pilota";
        $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare i piloti: " . $conn->error . "</p>");

        $piloti_vettore = array();
        foreach ($ris as $riga) {
            array_push($piloti_vettore, array($riga["codpilota"], $riga["nome"], $riga["cognome"]));
        }
        $indice_comandante = rand(0, sizeof($piloti_vettore) - 1);
        $codcomandante = $piloti_vettore[$indice_comandante][0];
        $num_copiloti = rand(1, 2); // estraggo il numero di copiloti
        $cod_copiloti = array();
        // cerco i copiloti che non devono ripetersi e non devono essere il comandante
        for ($j = 1; $j <= $num_copiloti; $j++) {
            do {
                $indice_copilota = rand(0, sizeof($piloti_vettore) - 1);
                $cod_copilota = $piloti_vettore[$indice_copilota][0];
            } while ($cod_copilota == $codcomandante || in_array($cod_copilota, $cod_copiloti));
            array_push($cod_copiloti, $cod_copilota);
        }

        // devo scegliere un aereo (per ora me ne frego se un aereo sta già volando in un'altra tratta, faccio lo stesso per i piloti)
        $query = "SELECT * FROM aereo";
        $ris = $conn->query($query) or die("<p>Errore quando cerco di caricare gli aerei: " . $conn->error . "</p>");
        $aerei_vettore = array();
        foreach ($ris as $riga) {
            array_push($aerei_vettore, $riga["codaereo"]);
        }
        $cod_aereo = $aerei_vettore[rand(0, sizeof($aerei_vettore) - 1)];

        // stampo i dati del volo costruito e che andrò a mettere nel db
        if($data_partenza != $data_arrivo){
        // if(true){
            // echo "<p>Tempo partenza: " . date('Y-m-d H:i', $tempo_partenza) . " - Tempo partenza in secondi: $tempo_partenza<br>";
            // echo "Durata: $durata - Durata ore: $durata_ore - Durata minuti $durata_minuti - Durata in secondi: $durata_in_secondi<br>";
            // echo "Tempo arrivo: " . date('Y-m-d H:i', $tempo_arrivo) . " - Tempo arrivo in secondi: $tempo_arrivo</p>";
            
            echo "<p>Partenza: " . $cod_partenza . " " . $data_partenza . " " . $ora_partenza . ". Arrivo: " . $cod_arrivo . " " . $data_arrivo . " " . $ora_arrivo . "<br>";
            echo "Aereo: " . $cod_aereo . "<br>";
            echo "Comandante: " . $codcomandante . " - Copiloti: ";
            foreach ($cod_copiloti as $cod_copilota) {
                echo $cod_copilota . " ";
            }
            echo "</p>";
        }

        // costruisco la query
        $query = "INSERT INTO volo (aeroportopartenza, datapartenza, orapartenza, aeroportoarrivo, dataarrivo, oraarrivo, aereo, comandante)
                  VALUES ($cod_partenza, '$data_partenza', '$ora_partenza', $cod_arrivo, '$data_arrivo', '$ora_arrivo', $cod_aereo, '$codcomandante')";
        $conn->query($query) or die("<p>Errore quando cerco di inserire un volo: " . $conn->error . "</p>");
        $cod_volo = $conn->insert_id;

        // aggiunti i voli devo aggiungere la relazione coi copiloti
        foreach ($cod_copiloti as $cod_copilota) {
            $query = "INSERT INTO copilota (codvolo, codpilota)
                      VALUES ($cod_volo, $cod_copilota)";
            $conn->query($query) or die("<p>Errore quando cerco di inserire una relazione volo copilota: " . $conn->error . "</p>");
        }
    }
    ?>
</body>

</html>