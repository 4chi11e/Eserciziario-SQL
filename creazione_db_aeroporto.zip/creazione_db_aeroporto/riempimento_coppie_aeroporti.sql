INSERT INTO durate_voli (partenza, arrivo)
SELECT A1.codaeroporto, A2.codaeroporto
FROM aeroporto AS A1 JOIN aeroporto AS A2
WHERE A1.codaeroporto <> A2.codaeroporto
	AND A1.codaeroporto < A2.codaeroporto